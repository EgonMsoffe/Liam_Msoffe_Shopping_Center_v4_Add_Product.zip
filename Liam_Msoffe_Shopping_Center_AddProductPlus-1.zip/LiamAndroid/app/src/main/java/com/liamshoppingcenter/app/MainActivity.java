package com.liamshoppingcenter.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebViewClient; import android.webkit.WebChromeClient; import android.webkit.WebSettings; import android.view.KeyEvent;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle saved){super.onCreate(saved); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setSupportZoom(true); s.setBuiltInZoomControls(false); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.loadUrl("file:///android_asset/index.html"); }
 @Override public boolean onKeyDown(int key, KeyEvent event){if(key==KeyEvent.KEYCODE_BACK && web.canGoBack()){web.goBack();return true;}return super.onKeyDown(key,event);}
 @Override protected void onDestroy(){if(web!=null){web.destroy();}super.onDestroy();}
}
